# codigo/lib/api_client.py
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry # Correct import for Retry
import logging
import os
import json # Import json for exception handling
from datetime import datetime

logger = logging.getLogger(__name__)

def create_session_with_retries(retries=3, backoff_factor=0.5, status_forcelist=(500, 502, 503, 504)):
    """Crea una sesión de Requests con reintentos configurados."""
    session = requests.Session()
    retry_strategy = Retry( # Use Retry directly
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        allowed_methods=["POST", "GET"] # Explicitly allow POST for retries if needed
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    # Mount for both http and https
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    logger.debug("Requests Session con reintentos creada para API Client.")
    return session


class ImageTextExtractorAPI:
    def __init__(self, api_url, api_key):
        if not api_url or not api_key:
             raise ValueError("Se requiere URL y Clave API para ImageTextExtractorAPI")
        # Store the raw URL, removing potential markdown
        self.api_url = api_url.strip().strip('[]()') # Limpiar URL por si acaso
        self.headers = {"Authorization": api_key}
        # Crear una sesión persistente para este cliente
        self.session = create_session_with_retries()
        logger.info(f"Cliente API inicializado para URL: {self.api_url}")


    def extract_text_from_image(self, image_path):
        """
        Envía una imagen a la API de análisis de documentos y extrae el texto,
        usando una sesión con reintentos.
        """
        if not os.path.exists(image_path):
            logger.error(f"Archivo de imagen no encontrado: {image_path}")
            return {
                "image_filename": os.path.basename(image_path),
                "processed_date": datetime.today().strftime('%d%m%Y'),
                "extracted_text": "",
                "error": "File not found"
            }

        result = {
             "image_filename": os.path.basename(image_path),
             "processed_date": datetime.today().strftime('%d%m%Y'),
             "extracted_text": "",
             "error": None
        }

        try:
            with open(image_path, "rb") as image_file:
                files = {"image": (os.path.basename(image_path), image_file)}
                logger.debug(f"Enviando imagen {os.path.basename(image_path)} a la API: {self.api_url}")
                # Usar la sesión del cliente para la solicitud POST
                response = self.session.post(self.api_url, files=files, headers=self.headers, timeout=60)
                response.raise_for_status()

            response_json = response.json()
            logger.debug(f"Respuesta API para {os.path.basename(image_path)}: Status {response.status_code}") # Log status

            # Adaptar según estructura REAL (igual que antes)
            if response_json and "data" in response_json and "chunks" in response_json["data"]:
                chunks = response_json["data"]["chunks"]
                text = " ".join(chunk.get("text", "") for chunk in chunks if isinstance(chunk, dict))
                result["extracted_text"] = ' '.join(text.split())
                logger.info(f"Texto extraído de {os.path.basename(image_path)} ({len(result['extracted_text'])} chars).")
            else:
                 logger.warning(f"Respuesta de API inesperada o sin texto para {os.path.basename(image_path)}. Respuesta: {response_json}")
                 result["error"] = "Unexpected API response structure or no text found"


        except requests.exceptions.RequestException as e:
            # Log más detallado del error de requests
            logger.error(f"Error de red/HTTP procesando {os.path.basename(image_path)} con la API: {type(e).__name__} - {e}")
            result["error"] = f"API Request failed: {type(e).__name__} - {e}"
        except json.JSONDecodeError:
             logger.error(f"Error decodificando respuesta JSON de la API para {os.path.basename(image_path)}")
             result["error"] = "Invalid JSON response from API"
        except Exception as e:
            logger.error(f"Error inesperado procesando {os.path.basename(image_path)} con la API: {str(e)}", exc_info=True) # Log stack trace
            result["error"] = f"Unexpected error: {str(e)}"

        return result